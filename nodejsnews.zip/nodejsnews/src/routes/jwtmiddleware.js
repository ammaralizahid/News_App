
exports.Loggedin= async(req,res,next)=>{

    try {

        const user= res.locals.loggedinuser
        if(!user){

            return res.status(401).json({
                error:"you need to be logged in"
            })

        }
        next();

        
    } catch (err) {

        next(err)
        
    }
}