// const accesscontrol= require('accesscontrol');
// const ac= new accesscontrol();




// exports.roles= (function (){

//     ac.grant('user').readOwn('profile').updateOwn('profile')

//     ac.grant('writer').extend('user').readAny('profile')

//     ac.grant('admin').extend('user').extend('writer').updateAny('profile').deleteAny('profile')

//     return ac;


// })();

const User= require("../../models/user")

const rolesnpermission=function(...role){

    return ( req,res,next)=>{

        if(!role.includes(req.user.role)){

            return res.status(400).send("you have no role");

        }

        next();

    }


}

module.exports = rolesnpermission;