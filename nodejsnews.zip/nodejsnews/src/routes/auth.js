const router= require('express').Router();
const User = require("../../models/user");
const nodemailer = require('nodemailer')
const role= require('./rolemiddleware')
const rolesnpermission = require('./role');
const bcrypt= require('bcrypt');
const jwt = require('jsonwebtoken')
const login= require('./jwtmiddleware')




router.get('/register' , (req,res)=>{

    res.render('partials/register')
});

router.post('/register', async(req,res)=>{
     
   
   
    //gensalt will create 10 words of each word. Bcrypt will encrypt it
   const salt= await bcrypt.genSalt(10);
   const hashpassword= await bcrypt.hash(req.body.password, salt);
   const newUser = new User({ 
 
       username: req.body.username, 
 
       email: req.body.email,

       password:hashpassword,  

       role: req.body.role,

       



     

   });

     
   const accessToken = jwt.sign({userId: newUser._id}, process.env.TOKEN_SECRET, { expiresIn : "15m"}); 
   newUser.accessToken= accessToken;
 
   const mail = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    auth: {
        user: 'amilzak42@gmail.com',
        pass: 'yxeeoklsghhcdqsq', //generated ethereal password
    }

});

const info= await mail.sendMail({ 
    from: 'amilzak42@gmail.com',
    to: req.body.email,
    text: "testing", // plain text body
    html: req.body.username,

    
});



   
    try {
      
        const user = await newUser.save();
        res.redirect('/')
        
        
    } 
    catch (err) {
        res.status(500).json(err);
    }

}); 


router.get('/login'   , (req,res)=>{

    res.render('partials/login')
});

router.post("/login",  async(req,res)=>{

    try {
        
        // const {error}= loginvalidation(req.body);
        // if(error) return res.status(400).send(error.details[0].message);    

        const user= await User.findOne({username: req.body.username});
         !user && res.status(400).json("Wrong Credentials"); 
        
  
 
        const validate= await bcrypt.compare(req.body.password, user.password);
        !validate && res.status(400).json("Wrong Credentials");

        
        const token = jwt.sign({userId: user._id}, process.env.TOKEN_SECRET, { expiresIn : "15m"}); 
        await User.findByIdAndUpdate(user._id , {token});
        res.status(200).json({ token})

res.redirect('/')
        
    }  



   
   
    
    catch (err) {
     
        res.status(500).json(err);
    }

  
});

router.get("/:id", login.Loggedin, async(req,res)=>{

    if(req.body.userId === req.params.id)
    {
     
    try {
        
        const user= await User.findById(req.params.id)
        const {password, ...others}= user._doc;
        res.status(200).json(others);

    } 
 
  catch (err) { 
        
        res.status(500).json(err)
    }
}
  });


 
module.exports = router